#include <pspkernel.h>
#include <pspgu.h>
#include <pspgum.h>
#include <pspdisplay.h>
#include <pspctrl.h>
#include <math.h>
#include <string.h>

#define SCREEN_W 480
#define SCREEN_H 272
#define BUF_W 512

typedef struct { unsigned int color; float x, y, z; } Vertex;
static unsigned int __attribute__((aligned(16))) list[262144];

static float maxX = 105.0f, maxY = 0.0f, maxVY = 0.0f;
static float enemyX = 345.0f;
static int facing = 1;
static int maxHP = 100, enemyHP = 100;
static int attackFrames = 0, attackCooldown = 0, hurtFrames = 0;
static int won = 0;
static unsigned int previousButtons = 0;

static void rect(float x, float y, float w, float h, unsigned int color) {
    Vertex v[4] = {
        {color, x,     y,     0},
        {color, x + w, y,     0},
        {color, x + w, y + h, 0},
        {color, x,     y + h, 0}
    };
    sceGuDrawArray(GU_TRIANGLE_FAN,
        GU_COLOR_8888 | GU_VERTEX_32BITF | GU_TRANSFORM_2D,
        4, 0, v);
}

static void drawTextHint(void) {
    // The first combat prototype uses shapes and HUD bars; text will be added
    // with a bitmap font in the next pass.
    rect(10, 10, 150, 8, 0xFF333333);
    rect(10, 10, 150.0f * maxHP / 100.0f, 8, 0xFF22CC55);
    rect(320, 10, 150, 8, 0xFF333333);
    rect(320, 10, 150.0f * enemyHP / 100.0f, 8, 0xFF2222DD);
    rect(10, 24, 70, 3, 0xFFAAAAAA);
    rect(320, 24, 70, 3, 0xFFAAAAAA);
}

static void drawMax(void) {
    float x = maxX, y = 188.0f - maxY;
    unsigned int body = hurtFrames > 0 ? 0xFF7777FF : 0xFF333333;
    // Dark trousers, boots, torso, head and the red scarf.
    rect(x + 10, y + 40, 22, 22, 0xFF151515);
    rect(x + 7, y + 57, 12, 7, 0xFF080808);
    rect(x + 24, y + 57, 12, 7, 0xFF080808);
    rect(x + 8, y + 15, 28, 28, body);
    rect(x + 12, y + 2, 20, 16, 0xFFB98A68);
    rect(x + 7, y + 14, 30, 5, 0xFF2222AA); // dark red scarf
    // Sword extends toward the facing direction during an attack.
    if (attackFrames > 0) {
        if (facing > 0) rect(x + 30, y + 26, 43, 5, 0xFFDDDDDD);
        else             rect(x - 37, y + 26, 43, 5, 0xFFDDDDDD);
    } else {
        if (facing > 0) rect(x + 31, y + 28, 22, 4, 0xFFBBBBBB);
        else             rect(x - 15, y + 28, 22, 4, 0xFFBBBBBB);
    }
}

static void drawEnemy(void) {
    float x = enemyX;
    rect(x + 7, 190, 30, 27, 0xFF252575);
    rect(x + 3, 214, 13, 8, 0xFF101010);
    rect(x + 27, 214, 13, 8, 0xFF101010);
    rect(x + 12, 175, 21, 17, 0xFF777777);
    rect(x + 8, 174, 28, 5, 0xFF111111);
    rect(x + 10, 181, 5, 3, 0xFF2222FF);
    rect(x + 28, 181, 5, 3, 0xFF2222FF);
}

static void initGraphics(void) {
    sceGuInit();
    sceGuStart(GU_DIRECT, list);
    sceGuDrawBuffer(GU_PSM_8888, (void*)0, BUF_W);
    sceGuDispBuffer(SCREEN_W, SCREEN_H, (void*)0x88000, BUF_W);
    sceGuDepthBuffer((void*)0x110000, BUF_W);
    sceGuOffset(2048 - SCREEN_W / 2, 2048 - SCREEN_H / 2);
    sceGuViewport(2048, 2048, SCREEN_W, SCREEN_H);
    sceGuDepthRange(65535, 0);
    sceGuScissor(0, 0, SCREEN_W, SCREEN_H);
    sceGuEnable(GU_SCISSOR_TEST);
    sceGuDisable(GU_DEPTH_TEST);
    sceGuFinish();
    sceGuSync(0, 0);
    sceDisplayWaitVblankStart();
    sceGuDisplay(GU_TRUE);
}

static void update(SceCtrlData pad) {
    unsigned int pressed = pad.Buttons & ~previousButtons;
    previousButtons = pad.Buttons;

    if (won) {
        if (pressed & PSP_CTRL_START) {
            maxHP = 100; enemyHP = 100; maxX = 105; enemyX = 345;
            maxY = 0; maxVY = 0; won = 0;
        }
        return;
    }

    float dx = 0;
    if (pad.Buttons & PSP_CTRL_LEFT)  dx -= 3.0f;
    if (pad.Buttons & PSP_CTRL_RIGHT) dx += 3.0f;
    if (pad.Lx < 110) dx -= (110 - pad.Lx) * 0.035f;
    if (pad.Lx > 145) dx += (pad.Lx - 145) * 0.035f;
    if (dx > 0.2f) facing = 1;
    if (dx < -0.2f) facing = -1;
    maxX += dx;
    if (maxX < 5) maxX = 5;
    if (maxX > 425) maxX = 425;

    if ((pressed & PSP_CTRL_CROSS) && maxY <= 0.1f) maxVY = 8.2f;
    maxY += maxVY;
    maxVY -= 0.42f;
    if (maxY < 0) { maxY = 0; maxVY = 0; }

    if (attackCooldown > 0) attackCooldown--;
    if (attackFrames > 0) attackFrames--;
    if (hurtFrames > 0) hurtFrames--;

    if ((pressed & PSP_CTRL_SQUARE) && attackCooldown == 0) {
        attackFrames = 9;
        attackCooldown = 22;
        // Sword hit check: range and direction must overlap the enemy.
        float distance = enemyX - maxX;
        if ((facing > 0 && distance >= 0 && distance < 92) ||
            (facing < 0 && distance < 0 && distance > -55)) {
            enemyHP -= 25;
            if (enemyHP < 0) enemyHP = 0;
        }
    }

    // Enemy approaches slowly and damages Max on contact.
    if (enemyHP > 0) {
        if (enemyX > maxX + 48) enemyX -= 0.35f;
        if (enemyX < maxX + 24) enemyX += 0.35f;
        if (fabsf(enemyX - maxX) < 43 && hurtFrames == 0) {
            maxHP -= 1;
            hurtFrames = 18;
            if (maxHP < 0) maxHP = 0;
        }
    }
    if (enemyHP == 0) won = 1;
}

int main(void) {
    SceCtrlData pad;
    sceCtrlSetSamplingCycle(0);
    sceCtrlSetSamplingMode(PSP_CTRL_MODE_ANALOG);
    initGraphics();

    for (;;) {
        sceCtrlReadBufferPositive(&pad, 1);
        update(pad);

        sceGuStart(GU_DIRECT, list);
        sceGuClearColor(0xFF20202A);
        sceGuClearDepth(0);
        sceGuClear(GU_COLOR_BUFFER_BIT | GU_DEPTH_BUFFER_BIT);

        // Ashen village training ground.
        rect(0, 224, 480, 48, 0xFF292929);
        rect(0, 221, 480, 3, 0xFF555555);
        rect(35, 155, 35, 66, 0xFF383838);
        rect(395, 145, 45, 76, 0xFF303030);
        rect(0, 245, 480, 2, 0xFF777777);

        drawTextHint();
        drawMax();
        if (enemyHP > 0) drawEnemy();

        if (won) {
            rect(125, 105, 230, 5, 0xFF22CC55);
            rect(155, 120, 170, 4, 0xFFFFFFFF);
        } else if (maxHP == 0) {
            rect(125, 105, 230, 5, 0xFF2222DD);
            rect(155, 120, 170, 4, 0xFFFFFFFF);
        }

        sceGuFinish();
        sceGuSync(0, 0);
        sceDisplayWaitVblankStart();
        sceGuSwapBuffers();
    }
    sceGuTerm();
    sceKernelExitGame();
    return 0;
}
