# Max's Revenge — PSP combat prototype

This is a first playable-combat code prototype for PSP homebrew. It is not an ISO
and it has not been compiled in this environment.

## Controls
- D-pad left/right or analog stick: move
- X: jump
- Square: sword attack
- Start: restart after victory

## Build with PSPDEV
This project requires the PSPDEV SDK and its CMake integration.
From the project directory, run:

```sh
mkdir build
cd build
psp-cmake ..
make
```

The build should produce `EBOOT.PBP` in the build directory.

Copy the resulting file to:
`PSP/GAME/MaxRevenge/EBOOT.PBP`

Then open PPSSPP and launch it from Games/Homebrew.

## Prototype notes
- Max and the enemy are drawn with simple geometric shapes.
- The enemy has a health bar and loses health when a sword hit connects.
- The enemy approaches Max and can damage him on contact.
- This is the combat foundation; proper character artwork, animation, sound,
  Arabic font rendering, menus, and boss AI are planned for later passes.
