cmake_minimum_required(VERSION 3.11)
project(MaxRevenge C)

add_executable(MaxRevenge src/main.c)

target_link_libraries(MaxRevenge PRIVATE
    pspgu
    pspdisplay
    pspge
    pspctrl
    pspkernel
)

create_pbp_file(
    TARGET MaxRevenge
    TITLE "Max's Revenge - Combat Prototype"
    VERSION 01.00
    ICON_PATH NULL
    BACKGROUND_PATH NULL
    PREVIEW_PATH NULL
)
