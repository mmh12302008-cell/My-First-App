package com.khalfiyati.app

import android.content.Context

/** Stores favorite wallpaper ids locally on the device. */
object Favorites {
    private const val PREFS = "khalfiyati"
    private const val KEY = "fav_ids"

    fun ids(ctx: Context): Set<String> =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getStringSet(KEY, emptySet())?.toSet() ?: emptySet()

    fun toggle(ctx: Context, id: String): Set<String> {
        val current = ids(ctx).toMutableSet()
        if (!current.add(id)) current.remove(id)
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putStringSet(KEY, current).apply()
        return current
    }
}
