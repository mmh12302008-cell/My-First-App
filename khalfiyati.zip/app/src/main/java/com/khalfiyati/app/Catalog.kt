package com.khalfiyati.app

import android.app.WallpaperManager
import android.content.Context
import org.json.JSONObject

data class Wallpaper(
    val id: String,
    val section: String,
    val file: String
) {
    val assetPath: String get() = "wallpapers/$section/$file"
}

object Catalog {
    /** Display names for each series key. Unknown keys fall back to the key itself. */
    val SERIES_NAMES = mapOf(
        "naruto" to "ناروتو",
        "one_piece" to "ون بيس",
        "dragon_ball" to "دراغون بول",
        "demon_slayer" to "قاتل الشياطين",
        "jujutsu_kaisen" to "جوجتسو كايسن",
        "hunter_x_hunter" to "Hunter x Hunter",
        "my_hero_academia" to "My Hero Academia",
        "attack_on_titan" to "Attack on Titan",
        "tokyo_ghoul" to "Tokyo Ghoul",
        "blue_lock" to "Blue Lock",
        "bungo_stray_dogs" to "Bungo Stray Dogs",
        "other" to "أنمي متنوع"
    )

    /** Groups wallpapers by series, keeping only images that exist in assets. */
    fun load(ctx: Context): Map<String, List<Wallpaper>> {
        val root = JSONObject(ctx.assets.open("catalog.json").bufferedReader().readText())
        val arr = root.getJSONArray("anime")
        val presentCache = HashMap<String, Set<String>>()
        val result = LinkedHashMap<String, MutableList<Wallpaper>>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val series = o.getString("series")
            val files = presentCache.getOrPut(series) {
                ctx.assets.list("wallpapers/$series")?.toSet() ?: emptySet()
            }
            val file = o.getString("file")
            if (file in files) {
                result.getOrPut(series) { mutableListOf() }
                    .add(Wallpaper(o.getString("id"), series, file))
            }
        }
        return result
    }

    fun applyToHomeScreen(ctx: Context, wallpaper: Wallpaper) {
        val wm = WallpaperManager.getInstance(ctx)
        ctx.assets.open(wallpaper.assetPath).use { stream ->
            wm.setStream(stream, null, true, WallpaperManager.FLAG_SYSTEM)
        }
    }
}
