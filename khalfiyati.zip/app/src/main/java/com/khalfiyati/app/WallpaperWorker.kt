package com.khalfiyati.app

import android.content.Context
import android.util.Log
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.concurrent.TimeUnit

/**
 * Runs as WorkManager jobs instead of a long-lived service, so Android can
 * restart them after reboots and background limits. Failed runs are retried.
 */
class WallpaperWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        try {
            val pool = Catalog.load(applicationContext).values.flatten()
            if (pool.isEmpty()) return@withContext Result.success()
            Catalog.applyToHomeScreen(applicationContext, pool.random())
            Result.success()
        } catch (e: Exception) {
            Log.e(TAG, "Wallpaper rotation failed", e)
            Result.retry()
        }
    }

    companion object {
        private const val TAG = "Khalfiyati"
        private const val PERIODIC_NAME = "wallpaper_rotation"

        fun schedule(ctx: Context, hours: Long = 6) {
            val request = PeriodicWorkRequestBuilder<WallpaperWorker>(hours, TimeUnit.HOURS).build()
            WorkManager.getInstance(ctx).enqueueUniquePeriodicWork(
                PERIODIC_NAME, ExistingPeriodicWorkPolicy.KEEP, request
            )
        }

        /** Changes the wallpaper once, right now, to a random one. */
        fun runNow(ctx: Context) {
            WorkManager.getInstance(ctx).enqueue(OneTimeWorkRequestBuilder<WallpaperWorker>().build())
        }
    }
}
