package com.khalfiyati.app

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WallpaperWorker.schedule(this)
        setContent { MaterialTheme { KhalfiyatiScreen() } }
    }
}

private const val FAV_KEY = "__fav__"

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun KhalfiyatiScreen() {
    val ctx = LocalContext.current
    val sections = remember { Catalog.load(ctx) }
    val tabs = remember(sections) { sections.keys.toList() + FAV_KEY }
    var selected by remember { mutableIntStateOf(0) }
    var favs by remember { mutableStateOf(Favorites.ids(ctx)) }
    val scope = rememberCoroutineScope()

    val key = tabs.getOrElse(selected) { FAV_KEY }
    val list = if (key == FAV_KEY) {
        sections.values.flatten().filter { it.id in favs }
    } else {
        sections[key].orEmpty()
    }
    fun labelOf(k: String) = if (k == FAV_KEY) "المفضلة" else Catalog.SERIES_NAMES[k] ?: k

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("خلفيات أنمي") },
                actions = {
                    TextButton(onClick = {
                        WallpaperWorker.runNow(ctx)
                        Toast.makeText(ctx, "جاري تغيير الخلفية", Toast.LENGTH_SHORT).show()
                    }) { Text("تغيير الآن") }
                }
            )
        }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            ScrollableTabRow(selectedTabIndex = selected) {
                tabs.forEachIndexed { i, k ->
                    Tab(
                        selected = selected == i,
                        onClick = { selected = i },
                        text = { Text(labelOf(k)) }
                    )
                }
            }
            Text(
                if (key == FAV_KEY) "${list.size} محفوظة" else "${list.size} خلفية",
                modifier = Modifier.padding(12.dp),
                style = MaterialTheme.typography.labelMedium
            )
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                contentPadding = PaddingValues(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(list, key = { it.id }) { wp ->
                    Column {
                        AsyncImage(
                            model = "file:///android_asset/${wp.assetPath}",
                            contentDescription = wp.id,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(260.dp)
                                .clickable {
                                    scope.launch {
                                        try {
                                            withContext(Dispatchers.IO) { Catalog.applyToHomeScreen(ctx, wp) }
                                            Toast.makeText(ctx, "تم تعيين الخلفية", Toast.LENGTH_SHORT).show()
                                        } catch (e: Exception) {
                                            Toast.makeText(ctx, "تعذر تعيين الخلفية", Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                }
                        )
                        TextButton(onClick = { favs = Favorites.toggle(ctx, wp.id) }) {
                            Text(if (wp.id in favs) "♥ محفوظة" else "♡ حفظ")
                        }
                    }
                }
            }
        }
    }
}
